const translations = {
  en: {
    languageName: 'English',
    home: 'Home',
    search: 'Search',
    schedule: 'Schedule',
    settings: 'Settings',
    searchMedication: 'Search medication',
    today: 'Today',
    medicationSummary: 'Medication summary',
    dailySummaryPaused: 'Daily summary paused',
    voiceOn: 'Voice on',
    silent: 'Silent',
    myMedications: 'My medications',
    viewAll: 'View all',
    alerts: 'Alerts',
    appearance: 'Appearance',
    reminderPreferences: 'Reminder preferences',
    voiceAlerts: 'Voice alerts',
    dailySummary: 'Daily summary',
    autoRefill: 'Auto refill',
    darkMode: 'Dark mode',
    highContrast: 'High contrast',
    compactLayout: 'Compact layout',
    textSize: 'Text size',
    fontStyle: 'Font style',
    accentColor: 'Accent color',
    showSeconds: 'Show seconds',
    language: 'Language',
    tuneAppearance: 'Tune the reading size, color, spacing, clock, and language.',
    small: 'Small',
    default: 'Default',
    large: 'Large',
    system: 'System',
    serif: 'Serif',
    mono: 'Mono',
    ringtone: 'Ringtone',
    vibration: 'Vibration',
    reminderWindow: 'Reminder window',
    min: 'min',
  },
  es: {
    languageName: 'Español', home: 'Inicio', search: 'Buscar', schedule: 'Agenda', settings: 'Ajustes', searchMedication: 'Buscar medicamento', today: 'Hoy', medicationSummary: 'Resumen de medicamentos', dailySummaryPaused: 'Resumen diario pausado', voiceOn: 'Voz activa', silent: 'Silencio', myMedications: 'Mis medicamentos', viewAll: 'Ver todo', alerts: 'Alertas', appearance: 'Apariencia', reminderPreferences: 'Preferencias de recordatorios', voiceAlerts: 'Alertas de voz', dailySummary: 'Resumen diario', autoRefill: 'Reposición automática', darkMode: 'Modo oscuro', highContrast: 'Alto contraste', compactLayout: 'Diseño compacto', textSize: 'Tamaño del texto', fontStyle: 'Estilo de fuente', accentColor: 'Color de acento', showSeconds: 'Mostrar segundos', language: 'Idioma', tuneAppearance: 'Ajusta el tamaño, color, espacio, reloj e idioma.', small: 'Pequeño', default: 'Predeterminado', large: 'Grande', system: 'Sistema', serif: 'Serif', mono: 'Monoespaciada', ringtone: 'Tono', vibration: 'Vibración', reminderWindow: 'Ventana de recordatorio', min: 'min',
  },
  fr: {
    languageName: 'Français', home: 'Accueil', search: 'Rechercher', schedule: 'Planning', settings: 'Réglages', searchMedication: 'Rechercher un médicament', today: "Aujourd'hui", medicationSummary: 'Résumé des médicaments', dailySummaryPaused: 'Résumé quotidien en pause', voiceOn: 'Voix active', silent: 'Silencieux', myMedications: 'Mes médicaments', viewAll: 'Tout voir', alerts: 'Alertes', appearance: 'Apparence', reminderPreferences: 'Préférences de rappel', voiceAlerts: 'Alertes vocales', dailySummary: 'Résumé quotidien', autoRefill: 'Renouvellement automatique', darkMode: 'Mode sombre', highContrast: 'Contraste élevé', compactLayout: 'Mise en page compacte', textSize: 'Taille du texte', fontStyle: 'Style de police', accentColor: "Couleur d'accent", showSeconds: 'Afficher les secondes', language: 'Langue', tuneAppearance: "Réglez la taille, la couleur, l'espacement, l'horloge et la langue.", small: 'Petit', default: 'Par défaut', large: 'Grand', system: 'Système', serif: 'Serif', mono: 'Mono', ringtone: 'Sonnerie', vibration: 'Vibration', reminderWindow: 'Fenêtre de rappel', min: 'min',
  },
  de: {
    languageName: 'Deutsch', home: 'Start', search: 'Suche', schedule: 'Plan', settings: 'Einstellungen', searchMedication: 'Medikament suchen', today: 'Heute', medicationSummary: 'Medikamentenübersicht', dailySummaryPaused: 'Tagesübersicht pausiert', voiceOn: 'Sprache an', silent: 'Stumm', myMedications: 'Meine Medikamente', viewAll: 'Alle anzeigen', alerts: 'Warnungen', appearance: 'Darstellung', reminderPreferences: 'Erinnerungseinstellungen', voiceAlerts: 'Sprachalarme', dailySummary: 'Tagesübersicht', autoRefill: 'Automatisches Nachfüllen', darkMode: 'Dunkelmodus', highContrast: 'Hoher Kontrast', compactLayout: 'Kompaktes Layout', textSize: 'Textgröße', fontStyle: 'Schriftart', accentColor: 'Akzentfarbe', showSeconds: 'Sekunden anzeigen', language: 'Sprache', tuneAppearance: 'Größe, Farbe, Abstände, Uhr und Sprache anpassen.', small: 'Klein', default: 'Standard', large: 'Groß', system: 'System', serif: 'Serif', mono: 'Mono', ringtone: 'Klingelton', vibration: 'Vibration', reminderWindow: 'Erinnerungsfenster', min: 'Min.',
  },
  pt: {
    languageName: 'Português', home: 'Início', search: 'Buscar', schedule: 'Agenda', settings: 'Configurações', searchMedication: 'Buscar medicamento', today: 'Hoje', medicationSummary: 'Resumo dos medicamentos', dailySummaryPaused: 'Resumo diário pausado', voiceOn: 'Voz ativada', silent: 'Silencioso', myMedications: 'Meus medicamentos', viewAll: 'Ver tudo', alerts: 'Alertas', appearance: 'Aparência', reminderPreferences: 'Preferências de lembrete', voiceAlerts: 'Alertas de voz', dailySummary: 'Resumo diário', autoRefill: 'Reposição automática', darkMode: 'Modo escuro', highContrast: 'Alto contraste', compactLayout: 'Layout compacto', textSize: 'Tamanho do texto', fontStyle: 'Estilo da fonte', accentColor: 'Cor de destaque', showSeconds: 'Mostrar segundos', language: 'Idioma', tuneAppearance: 'Ajuste tamanho, cor, espaço, relógio e idioma.', small: 'Pequeno', default: 'Padrão', large: 'Grande', system: 'Sistema', serif: 'Serif', mono: 'Mono', ringtone: 'Toque', vibration: 'Vibração', reminderWindow: 'Janela de lembrete', min: 'min',
  },
  ja: {
    languageName: '日本語', home: 'ホーム', search: '検索', schedule: '予定', settings: '設定', searchMedication: '薬を検索', today: '今日', medicationSummary: '服薬サマリー', dailySummaryPaused: '日次サマリーは一時停止中', voiceOn: '音声オン', silent: 'サイレント', myMedications: '自分の薬', viewAll: 'すべて表示', alerts: '通知', appearance: '外観', reminderPreferences: 'リマインダー設定', voiceAlerts: '音声通知', dailySummary: '日次サマリー', autoRefill: '自動補充', darkMode: 'ダークモード', highContrast: '高コントラスト', compactLayout: 'コンパクト表示', textSize: '文字サイズ', fontStyle: 'フォント', accentColor: 'アクセントカラー', showSeconds: '秒を表示', language: '言語', tuneAppearance: '文字、色、間隔、時計、言語を調整します。', small: '小', default: '標準', large: '大', system: 'システム', serif: 'セリフ', mono: '等幅', ringtone: '着信音', vibration: 'バイブレーション', reminderWindow: 'リマインダー時間', min: '分',
  },
  zh: {
    languageName: '简体中文', home: '首页', search: '搜索', schedule: '日程', settings: '设置', searchMedication: '搜索药物', today: '今天', medicationSummary: '用药摘要', dailySummaryPaused: '每日摘要已暂停', voiceOn: '语音开启', silent: '静音', myMedications: '我的药物', viewAll: '查看全部', alerts: '提醒', appearance: '外观', reminderPreferences: '提醒偏好', voiceAlerts: '语音提醒', dailySummary: '每日摘要', autoRefill: '自动补充', darkMode: '深色模式', highContrast: '高对比度', compactLayout: '紧凑布局', textSize: '文字大小', fontStyle: '字体样式', accentColor: '强调色', showSeconds: '显示秒数', language: '语言', tuneAppearance: '调整文字大小、颜色、间距、时钟和语言。', small: '小', default: '默认', large: '大', system: '系统', serif: '衬线', mono: '等宽', ringtone: '铃声', vibration: '振动', reminderWindow: '提醒时间窗口', min: '分钟',
  },
  hi: {
    languageName: 'हिन्दी', home: 'होम', search: 'खोजें', schedule: 'शेड्यूल', settings: 'सेटिंग्स', searchMedication: 'दवा खोजें', today: 'आज', medicationSummary: 'दवा सारांश', dailySummaryPaused: 'दैनिक सारांश रुका हुआ है', voiceOn: 'आवाज़ चालू', silent: 'मौन', myMedications: 'मेरी दवाएं', viewAll: 'सभी देखें', alerts: 'अलर्ट', appearance: 'दिखावट', reminderPreferences: 'रिमाइंडर प्राथमिकताएं', voiceAlerts: 'वॉइस अलर्ट', dailySummary: 'दैनिक सारांश', autoRefill: 'ऑटो रिफिल', darkMode: 'डार्क मोड', highContrast: 'उच्च कंट्रास्ट', compactLayout: 'कॉम्पैक्ट लेआउट', textSize: 'टेक्स्ट आकार', fontStyle: 'फॉन्ट शैली', accentColor: 'एक्सेंट रंग', showSeconds: 'सेकंड दिखाएं', language: 'भाषा', tuneAppearance: 'टेक्स्ट, रंग, अंतर, घड़ी और भाषा बदलें।', small: 'छोटा', default: 'डिफ़ॉल्ट', large: 'बड़ा', system: 'सिस्टम', serif: 'सेरिफ', mono: 'मोनो', ringtone: 'रिंगटोन', vibration: 'वाइब्रेशन', reminderWindow: 'रिमाइंडर विंडो', min: 'मिनट',
  },
};

export const languageOptions = Object.entries(translations).map(([value, content]) => ({ value, label: content.languageName }));

export function getTranslation(language = 'en') {
  return translations[language] || translations.en;
}
