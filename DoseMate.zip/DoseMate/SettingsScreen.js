import { StyleSheet, View, Text, TouchableOpacity, ScrollView, Vibration } from 'react-native';

export default function SettingsScreen() {
  const playSound = (buttonLabel, frequency) => {
    // Unique patterns for settings buttons
    const patterns = {
      'Pew': [100, 50],
      'Pow': [150, 75],
      'Zap': [50, 100, 50],
      'Boom': [200],
      'Splash': [100, 100, 100],
      'Snap': [75, 25],
      'Crunch': [50, 30, 50, 30],
      'Ting': [125],
      'Tap': [40],
    };

    const pattern = patterns[buttonLabel] || [100];
    Vibration.vibrate(pattern);
    console.log(`🎶 ${buttonLabel} played!`);
  };

  const buttons = [
    { label: 'Pew', color: '#A8E6CF' },
    { label: 'Pow', color: '#FFD3B6' },
    { label: 'Zap', color: '#FFAAA5' },
    { label: 'Boom', color: '#FF8B94' },
    { label: 'Splash', color: '#8EC5FC' },
    { label: 'Snap', color: '#B19CD9' },
    { label: 'Crunch', color: '#FFB347' },
    { label: 'Ting', color: '#87CEEB' },
    { label: 'Tap', color: '#90EE90' },
  ];

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Settings - More Sounds</Text>
      <View style={styles.buttonsGrid}>
        {buttons.map((btn, index) => (
          <TouchableOpacity
            key={index}
            style={[styles.button, { backgroundColor: btn.color }]}
            onPress={() => playSound(btn.label, 400 + index * 75)}
            activeOpacity={0.7}
          >
            <Text style={styles.buttonText}>{btn.label}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  buttonsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  button: {
    width: '31%',
    paddingVertical: 20,
    marginBottom: 15,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  buttonText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#fff',
  },
});

