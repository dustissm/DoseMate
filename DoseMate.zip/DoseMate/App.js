import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert,
  Animated,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  Vibration,
  View,
} from 'react-native';
import { Audio } from 'expo-av';
import { Ionicons } from '@expo/vector-icons';

import HomeScreen from './HomeScreen';
import { getTranslation, languageOptions } from './localization';

const defaultSettings = {
  ringtone: 'Chime',
  vibration: 'Medium',
  reminderWindow: 15,
  voiceAlerts: true,
  dailySummary: true,
  autoRefill: true,
  caregiverAlerts: true,
  safetyAlerts: true,
  darkMode: false,
  highContrast: false,
  compactMode: false,
  showSeconds: false,
  fontScale: 1,
  fontFamily: 'System',
  accentColor: '#F97316',
  language: 'en',
};

const ringtoneMap = {
  Chime: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
  Bell: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
  Pulse: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
  Ocean: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
  'Soft Piano': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3',
};

const vibrationPatterns = {
  Light: [40],
  Medium: [90, 60, 90],
  Strong: [150, 80, 150, 80, 180],
};

let activeToneSound = null;
let activeClickSound = null;

function playButtonClick() {
  const tone = {
    frequency: 820,
    duration: 0.08,
    volume: 0.45,
  };

  const sampleRate = 22050;
  const totalSamples = Math.floor(sampleRate * tone.duration);
  const buffer = new ArrayBuffer(44 + totalSamples * 2);
  const view = new DataView(buffer);

  const writeString = (offset, value) => {
    for (let i = 0; i < value.length; i += 1) {
      view.setUint8(offset + i, value.charCodeAt(i));
    }
  };

  writeString(0, 'RIFF');
  view.setUint32(4, 36 + totalSamples * 2, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeString(36, 'data');
  view.setUint32(40, totalSamples * 2, true);

  let offset = 44;
  for (let i = 0; i < totalSamples; i += 1) {
    const time = i / sampleRate;
    const envelope = Math.exp(-time * 14);
    const wave = Math.sin(2 * Math.PI * tone.frequency * time) * envelope * tone.volume;
    view.setInt16(offset, Math.max(-1, Math.min(1, wave)) * 32767, true);
    offset += 2;
  }

  const bytes = new Uint8Array(buffer);
  let binary = '';
  bytes.forEach((byte) => {
    binary += String.fromCharCode(byte);
  });

  const url = `data:audio/wav;base64,${btoa(binary)}`;

  if (activeClickSound) {
    activeClickSound.unloadAsync().catch(() => null);
  }

  const sound = new Audio.Sound();
  activeClickSound = sound;

  sound.loadAsync({ uri: url }).then(() => {
    sound.playAsync();
    setTimeout(() => sound.unloadAsync().catch(() => null), 250);
  }).catch(() => null);
}

export async function playTestRingtone(ringtoneName, vibrationName = 'Medium') {
  const uri = ringtoneMap[ringtoneName] || ringtoneMap.Chime;
  const vibration = vibrationPatterns[vibrationName] || vibrationPatterns.Medium;
  Vibration.vibrate(vibration);

  if (activeToneSound) {
    try {
      await activeToneSound.stopAsync();
    } catch (error) {
      // no-op
    }
    try {
      await activeToneSound.unloadAsync();
    } catch (error) {
      // no-op
    }
  }

  const sound = new Audio.Sound();
  activeToneSound = sound;

  try {
    try {
      await Audio.setAudioModeAsync({ playsInSilentMode: true, staysActiveInBackground: false });
    } catch (audioModeError) {
      // Some web environments do not expose the native audio session API.
    }
    await sound.loadAsync({ uri });
    await sound.playAsync();
    setTimeout(async () => {
      try {
        await sound.unloadAsync();
      } catch (error) {
        // no-op
      }
    }, 1800);
  } catch (error) {
    activeToneSound = null;
    await sound.unloadAsync().catch(() => null);
    playButtonClick();
  }
}

function getMedicationInsights(items) {
  if (!items.length) {
    return { total: 0, refillSoon: 0, adherence: 100, alertCount: 0 };
  }

  const refillSoon = items.filter((medication) => Number(medication.refillDays || 0) <= 7).length;
  const alertCount = items.filter((medication) => Number(medication.refillDays || 0) <= 14).length;
  const adherence = Math.min(98, Math.max(74, 90 - refillSoon * 2 + items.length));

  return {
    total: items.length,
    refillSoon,
    adherence: Math.round(adherence),
    alertCount,
  };
}

const initialMedications = [
  {
    id: 'm1',
    name: 'Metformin',
    type: 'Diabetes',
    dose: '500mg',
    frequency: 'Twice daily',
    time: '08:00',
    days: 'Mon Tue Wed Thu Fri Sat Sun',
    notes: 'Take with breakfast and a full glass of water.',
    refillDays: '7',
    ringtone: 'Chime',
    color: '#34D399',
  },
  {
    id: 'm2',
    name: 'Amoxicillin',
    type: 'Antibiotic',
    dose: '250mg',
    frequency: 'Daily',
    time: '12:30',
    days: 'Mon Tue Wed Thu Fri',
    notes: 'Finish the full course unless a doctor says otherwise.',
    refillDays: '3',
    ringtone: 'Bell',
    color: '#60A5FA',
  },
  {
    id: 'm3',
    name: 'Vitamin D',
    type: 'Supplement',
    dose: '1000 IU',
    frequency: 'Daily',
    time: '19:00',
    days: 'Mon Tue Wed Thu Fri Sat Sun',
    notes: 'Take after dinner with a meal.',
    refillDays: '14',
    ringtone: 'Pulse',
    color: '#FBBF24',
  },
];

const actionCards = [
  { key: 'refill', title: 'Refill', subtitle: 'Reminder', icon: 'notifications-outline', color: '#FDE68A' },
  { key: 'add', title: 'Add', subtitle: 'Medication', icon: 'add-circle-outline', color: '#BBF7D0' },
  { key: 'appointment', title: 'Upcoming', subtitle: 'Appointment', icon: 'calendar-outline', color: '#BFDBFE' },
  { key: 'scan', title: 'Scan', subtitle: 'Prescription', icon: 'scan-outline', color: '#DDD6FE' },
];

const bottomNav = [
  { key: 'home', label: 'Home', icon: 'home-outline' },
  { key: 'search', label: 'Search', icon: 'search-outline' },
  { key: 'schedule', label: 'Schedule', icon: 'calendar-outline' },
  { key: 'settings', label: 'Settings', icon: 'settings-outline' },
];

const ringtoneOptions = ['Chime', 'Bell', 'Pulse', 'Ocean', 'Soft Piano'];
const frequencyOptions = ['Daily', 'Twice daily', 'Weekly', 'As needed'];
const colorOptions = ['#34D399', '#60A5FA', '#FBBF24', '#F87171', '#A78BFA', '#FB7185'];

function getEmptyMedication() {
  return {
    id: '',
    name: '',
    type: '',
    dose: '',
    frequency: 'Daily',
    time: '08:00',
    days: 'Mon Tue Wed Thu Fri Sat Sun',
    notes: '',
    refillDays: '7',
    ringtone: 'Chime',
    color: '#34D399',
  };
}

function PageHeader({ title, subtitle, onBack, settings = {} }) {
  const isDark = !!settings.darkMode;
  const fontFamily = settings.fontFamily === 'Serif' ? 'Georgia' : settings.fontFamily === 'Mono' ? 'Courier New' : undefined;
  const scale = settings.fontScale || 1;

  return (
    <View style={[styles.pageHeader, isDark && styles.pageHeaderDark]}>
      {onBack ? (
        <TouchableOpacity onPress={onBack} style={styles.backButton}>
          <Ionicons name="arrow-back" size={22} color={isDark ? '#F8FAFC' : '#0F172A'} />
        </TouchableOpacity>
      ) : null}
      <View style={{ flex: 1 }}>
        <Text style={[styles.pageTitle, { color: isDark ? '#F8FAFC' : '#0F172A', fontSize: 26 * scale, fontFamily }]}>{title}</Text>
        {subtitle ? <Text style={[styles.pageSubtitle, { color: isDark ? '#CBD5E1' : '#64748B', fontSize: 14 * scale, fontFamily }]}>{subtitle}</Text> : null}
      </View>
    </View>
  );
}

function SettingToggle({ label, value, onToggle, color = '#F97316', textColor = '#1E293B', scale = 1, fontFamily }) {
  return (
    <View style={styles.settingRow}>
      <Text style={[styles.settingLabel, { color: textColor, fontSize: 15 * scale, fontFamily }]}>{label}</Text>
      <TouchableOpacity onPress={() => onToggle(!value)} style={[styles.toggle, value && { backgroundColor: color }]}>
        <View style={[styles.toggleKnob, value && styles.toggleKnobOn]} />
      </TouchableOpacity>
    </View>
  );
}

function SettingsScreen({ settings, onChange, onBack }) {
  const isDark = settings.darkMode;
  const scale = settings.fontScale || 1;
  const t = getTranslation(settings.language);
  const textColor = isDark ? '#F8FAFC' : '#0F172A';
  const mutedColor = isDark ? '#CBD5E1' : '#64748B';
  const fontFamily = settings.fontFamily === 'Serif' ? 'Georgia' : settings.fontFamily === 'Mono' ? 'Courier New' : undefined;

  return (
    <SafeAreaView style={[styles.screenShell, isDark && styles.screenShellDark]}>
      <PageHeader title={t.settings} subtitle={t.reminderPreferences} onBack={onBack} settings={settings} />

      <ScrollView style={styles.detailScroll} showsVerticalScrollIndicator={false}>
        <View style={[styles.settingsBlock, isDark && styles.settingsBlockDark]}>
          <Text style={[styles.settingsHeading, { color: textColor, fontSize: 15 * scale, fontFamily }]}>{t.alerts}</Text>

          <SettingToggle label={t.voiceAlerts} value={settings.voiceAlerts} onToggle={(value) => onChange('voiceAlerts', value)} color={settings.accentColor} textColor={textColor} scale={scale} fontFamily={fontFamily} />
          <SettingToggle label={t.dailySummary} value={settings.dailySummary} onToggle={(value) => onChange('dailySummary', value)} color={settings.accentColor} textColor={textColor} scale={scale} fontFamily={fontFamily} />
          <SettingToggle label={t.autoRefill} value={settings.autoRefill} onToggle={(value) => onChange('autoRefill', value)} color={settings.accentColor} textColor={textColor} scale={scale} fontFamily={fontFamily} />
          <SettingToggle label={t.darkMode} value={settings.darkMode} onToggle={(value) => onChange('darkMode', value)} color={settings.accentColor} textColor={textColor} scale={scale} fontFamily={fontFamily} />
          <SettingToggle label={t.highContrast} value={settings.highContrast} onToggle={(value) => onChange('highContrast', value)} color={settings.accentColor} textColor={textColor} scale={scale} fontFamily={fontFamily} />
          <SettingToggle label={t.compactLayout} value={settings.compactMode} onToggle={(value) => onChange('compactMode', value)} color={settings.accentColor} textColor={textColor} scale={scale} fontFamily={fontFamily} />
        </View>

        <View style={[styles.settingsBlock, isDark && styles.settingsBlockDark]}>
          <Text style={[styles.settingsHeading, { color: textColor, fontSize: 15 * scale, fontFamily }]}>{t.appearance}</Text>
          <Text style={[styles.settingsDescription, { color: mutedColor, fontSize: 13 * scale, fontFamily }]}>{t.tuneAppearance}</Text>
          <Text style={[styles.settingsLabel, { color: textColor, fontSize: 12 * scale, fontFamily }]}>{t.textSize}</Text>
          <View style={styles.chipRow}>
            {[{ label: t.small, value: 0.8 }, { label: t.default, value: 1 }, { label: t.large, value: 1.3 }].map((option) => (
              <TouchableOpacity
                key={option.label}
                onPress={() => onChange('fontScale', option.value)}
                style={[styles.optionChip, settings.fontScale === option.value && { backgroundColor: settings.accentColor }]}
              >
                <Text style={[styles.optionChipText, settings.fontScale === option.value && styles.optionChipTextSelected, { fontFamily }]}>{option.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={[styles.settingsLabel, { color: textColor, fontSize: 12 * scale, fontFamily }]}>{t.fontStyle}</Text>
          <View style={styles.chipRow}>
            {[{ label: t.system, value: 'System' }, { label: t.serif, value: 'Serif' }, { label: t.mono, value: 'Mono' }].map((option) => (
              <TouchableOpacity
                key={option.value}
                onPress={() => onChange('fontFamily', option.value)}
                style={[styles.optionChip, settings.fontFamily === option.value && { backgroundColor: settings.accentColor }]}
              >
                <Text style={[styles.optionChipText, settings.fontFamily === option.value && styles.optionChipTextSelected, { fontFamily }]}>{option.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={[styles.settingsLabel, { color: textColor, fontSize: 12 * scale, fontFamily }]}>{t.accentColor}</Text>
          <View style={styles.chipRow}>
            {['#F97316', '#0EA5E9', '#10B981', '#8B5CF6', '#E11D48'].map((color) => (
              <TouchableOpacity
                key={color}
                accessibilityLabel={`Choose accent ${color}`}
                onPress={() => onChange('accentColor', color)}
                style={[styles.colorSwatch, { backgroundColor: color }, settings.accentColor === color && styles.colorSwatchSelected]}
              />
            ))}
          </View>

          <SettingToggle label={t.showSeconds} value={settings.showSeconds} onToggle={(value) => onChange('showSeconds', value)} color={settings.accentColor} textColor={textColor} scale={scale} fontFamily={fontFamily} />
          <Text style={[styles.settingsLabel, { color: textColor, fontSize: 12 * scale, fontFamily }]}>{t.language}</Text>
          <View style={styles.chipRow}>
            {languageOptions.map((option) => (
              <TouchableOpacity
                key={option.value}
                onPress={() => onChange('language', option.value)}
                style={[styles.optionChip, settings.language === option.value && { backgroundColor: settings.accentColor }]}
              >
                <Text style={[styles.optionChipText, settings.language === option.value && styles.optionChipTextSelected, { fontFamily }]}>{option.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={[styles.settingsBlock, isDark && styles.settingsBlockDark]}>
          <Text style={[styles.settingsHeading, { color: textColor, fontSize: 15 * scale, fontFamily }]}>{t.ringtone}</Text>
          <View style={styles.chipRow}>
            {ringtoneOptions.map((option) => (
              <TouchableOpacity
                key={option}
                onPress={() => onChange('ringtone', option)}
                style={[styles.optionChip, settings.ringtone === option && { backgroundColor: settings.accentColor }]}
              >
                <Text style={[styles.optionChipText, settings.ringtone === option && styles.optionChipTextSelected, { fontFamily }]}>{option}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <TouchableOpacity
            style={[styles.primaryButton, { marginTop: 12, backgroundColor: settings.accentColor }]}
            onPress={() => playTestRingtone(settings.ringtone, settings.vibration)}
          >
            <Text style={[styles.primaryButtonText, { fontFamily }]}>Test ringtone</Text>
          </TouchableOpacity>
        </View>

        <View style={[styles.settingsBlock, isDark && styles.settingsBlockDark]}>
          <Text style={[styles.settingsHeading, { color: textColor, fontSize: 15 * scale, fontFamily }]}>{t.vibration}</Text>
          <View style={styles.chipRow}>
            {['Light', 'Medium', 'Strong'].map((option) => (
              <TouchableOpacity
                key={option}
                onPress={() => onChange('vibration', option)}
                style={[styles.optionChip, settings.vibration === option && { backgroundColor: settings.accentColor }]}
              >
                <Text style={[styles.optionChipText, settings.vibration === option && styles.optionChipTextSelected, { fontFamily }]}>{option}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={[styles.settingsBlock, isDark && styles.settingsBlockDark]}>
          <Text style={[styles.settingsHeading, { color: textColor, fontSize: 15 * scale, fontFamily }]}>{t.reminderWindow}</Text>
          <View style={styles.chipRow}>
            {[10, 15, 30, 60].map((option) => (
              <TouchableOpacity
                key={option}
                onPress={() => onChange('reminderWindow', option)}
                style={[styles.optionChip, settings.reminderWindow === option && { backgroundColor: settings.accentColor }]}
              >
                <Text style={[styles.optionChipText, settings.reminderWindow === option && styles.optionChipTextSelected, { fontFamily }]}>{option} {t.min}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function SectionCard({ title, value, accent, icon, settings = {} }) {
  const scale = settings.fontScale || 1;
  const fontFamily = settings.fontFamily === 'Serif' ? 'Georgia' : settings.fontFamily === 'Mono' ? 'Courier New' : undefined;

  return (
    <View style={[styles.infoCard, settings.darkMode && styles.infoCardDark, settings.compactMode && styles.infoCardCompact]}>
      <View style={[styles.infoIconWrap, { backgroundColor: accent }]}>
        <Ionicons name={icon} size={18} color="#0F172A" />
      </View>
      <View style={styles.infoTextWrap}>
        <Text style={[styles.infoTitle, { fontSize: 12 * scale, fontFamily }]}>{title}</Text>
        <Text style={[styles.infoValue, { fontSize: 16 * scale, fontFamily }]}>{value}</Text>
      </View>
    </View>
  );
}

function AppDetailScreen({ title, subtitle, items, onBack, settings = {} }) {
  const scale = settings.fontScale || 1;
  const isDark = settings.darkMode;
  const surface = isDark ? '#1F2937' : '#FFFFFF';
  const fontFamily = settings.fontFamily === 'Serif' ? 'Georgia' : settings.fontFamily === 'Mono' ? 'Courier New' : undefined;

  return (
    <SafeAreaView style={[styles.screenShell, isDark && styles.screenShellDark]}>
      <PageHeader title={title} subtitle={subtitle} onBack={onBack} settings={settings} />
      <ScrollView style={[styles.detailScroll, settings.compactMode && styles.detailScrollCompact]} showsVerticalScrollIndicator={false}>
        {items.map((item) => (
          <SectionCard key={item.title} title={item.title} value={item.value} accent={item.accent} icon={item.icon} settings={settings} />
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

function CalendarDayCell({ date, isCurrentMonth, isToday, reminders, onPress, settings }) {
  const scale = settings.fontScale || 1;
  const isDark = settings.darkMode;
  const highContrast = settings.highContrast;
  const surface = isDark ? '#1F2937' : '#FFFFFF';
  const textColor = highContrast ? (isDark ? '#F8FAFC' : '#020617') : isDark ? '#F8FAFC' : '#0F172A';
  const muted = highContrast ? (isDark ? '#E2E8F0' : '#334155') : '#64748B';
  const isDim = !isCurrentMonth;

  return (
    <Pressable
      onPress={() => onPress(date)}
      style={({ pressed }) => [
        styles.calendarCell,
        { backgroundColor: surface, transform: [{ scale: pressed ? 0.98 : 1 }] },
        isDim && { opacity: 0.5 },
        isToday && { borderColor: settings.accentColor, borderWidth: 2 },
      ]}
    >
      <Text style={[styles.calendarDayNumber, { color: textColor, fontSize: 12 * scale }]}>{date.getDate()}</Text>
      <View style={styles.calendarReminderRow}>
        {reminders.slice(0, 3).map((item) => (
          <View key={`${date.toISOString()}-${item.name}`} style={[styles.calendarDot, { backgroundColor: item.color || '#F97316' }]} />
        ))}
      </View>
      {reminders.length > 3 && <Text style={[styles.calendarMore, { color: muted, fontSize: 9 * scale }]}>+{reminders.length - 3}</Text>}
    </Pressable>
  );
}

function ScheduleScreen({ settings, medications, onBack }) {
  const [monthDate, setMonthDate] = useState(new Date(2026, 8, 1));
  const monthStart = new Date(monthDate.getFullYear(), monthDate.getMonth(), 1);
  const monthEnd = new Date(monthDate.getFullYear(), monthDate.getMonth() + 1, 0);
  const startOffset = (monthStart.getDay() + 6) % 7;
  const daysInMonth = monthEnd.getDate();
  const cells = [];

  for (let i = 0; i < startOffset; i += 1) {
    cells.push({ date: null, key: `empty-${i}` });
  }

  for (let day = 1; day <= daysInMonth; day += 1) {
    cells.push({ date: new Date(monthDate.getFullYear(), monthDate.getMonth(), day), key: `day-${day}` });
  }

  while (cells.length % 7 !== 0) {
    cells.push({ date: null, key: `tail-${cells.length}` });
  }

  const reminderMap = new Map();
  medications.forEach((medication) => {
    const [hours, minutes] = (medication.time || '08:00').split(':').map(Number);
    const dayValue = new Date(monthDate.getFullYear(), monthDate.getMonth(), 1);
    const monthValue = monthDate.getMonth();
    for (let i = 1; i <= daysInMonth; i += 1) {
      const candidate = new Date(monthDate.getFullYear(), monthDate.getMonth(), i);
      const candidateDay = candidate.getDay();
      const dayString = candidate.toLocaleDateString('en-US', { weekday: 'short' });
      const days = (medication.days || '').split(' ');
      if (days.includes(dayString)) {
        const key = candidate.toDateString();
        const entry = { time: medication.time, name: medication.name, color: medication.color, dosing: medication.dose, date: candidate, hour: hours, minute: minutes };
        const current = reminderMap.get(key) || [];
        current.push(entry);
        reminderMap.set(key, current);
      }
    }
  });

  const today = new Date();
  const monthLabel = monthDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  return (
    <SafeAreaView style={[styles.screenShell, settings.darkMode && styles.screenShellDark]}>
      <PageHeader title="Schedule" subtitle={monthLabel} onBack={onBack} settings={settings} />
      <View style={[styles.calendarHeaderRow, settings.darkMode && styles.calendarHeaderRowDark]}>
        <Pressable onPress={() => setMonthDate(new Date(monthDate.getFullYear(), monthDate.getMonth() - 1, 1))} style={({ pressed }) => [styles.calendarNavButton, { transform: [{ scale: pressed ? 0.97 : 1 }] }]}>
          <Ionicons name="chevron-back" size={18} color={settings.darkMode ? '#F8FAFC' : '#0F172A'} />
        </Pressable>
        <Text style={[styles.monthLabel, { color: settings.highContrast ? (settings.darkMode ? '#F8FAFC' : '#020617') : settings.darkMode ? '#F8FAFC' : '#0F172A', fontSize: 18 * (settings.fontScale || 1) }]}>{monthLabel}</Text>
        <Pressable onPress={() => setMonthDate(new Date(monthDate.getFullYear(), monthDate.getMonth() + 1, 1))} style={({ pressed }) => [styles.calendarNavButton, { transform: [{ scale: pressed ? 0.97 : 1 }] }]}>
          <Ionicons name="chevron-forward" size={18} color={settings.darkMode ? '#F8FAFC' : '#0F172A'} />
        </Pressable>
      </View>
      <View style={styles.weekdayRow}>
        {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day) => (
          <Text key={day} style={[styles.weekdayText, { color: settings.darkMode ? '#CBD5E1' : '#64748B', fontSize: 12 * (settings.fontScale || 1) }]}>{day}</Text>
        ))}
      </View>
      <View style={styles.calendarGrid}>
        {cells.map((cell) => {
          if (!cell.date) {
            return <View key={cell.key} style={styles.calendarCellPlaceholder} />;
          }

          const key = cell.date.toDateString();
          const reminders = reminderMap.get(key) || [];
          return (
            <CalendarDayCell
              key={key}
              date={cell.date}
              isCurrentMonth={cell.date.getMonth() === monthDate.getMonth()}
              isToday={cell.date.toDateString() === today.toDateString()}
              reminders={reminders}
              settings={settings}
              onPress={(date) => {
                const matches = reminderMap.get(date.toDateString()) || [];
                Alert.alert(
                  date.toDateString(),
                  matches.length ? matches.map((item) => `${item.name} • ${item.time}`).join('\n') : 'No reminders for this day.'
                );
              }}
            />
          );
        })}
      </View>
    </SafeAreaView>
  );
}

function MedicationDetailScreen({ medication, settings, onBack, onEdit, onDelete }) {
  const isDark = !!settings.darkMode;
  const fontFamily = settings.fontFamily === 'Serif' ? 'Georgia' : settings.fontFamily === 'Mono' ? 'Courier New' : undefined;
  const scale = settings.fontScale || 1;

  return (
    <SafeAreaView style={[styles.screenShell, isDark && styles.screenShellDark]}>
      <PageHeader title={medication.name} subtitle={medication.type} onBack={onBack} settings={settings} />
      <ScrollView style={[styles.detailScroll, settings.compactMode && styles.detailScrollCompact]} showsVerticalScrollIndicator={false}>
        <View style={[styles.medDetailCard, { borderColor: medication.color, backgroundColor: isDark ? '#1F2937' : '#FFFFFF' }]}> 
          <Text style={[styles.detailBadge, { color: isDark ? '#CBD5E1' : '#475569', fontFamily }]}>Next dose</Text>
          <Text style={[styles.detailTime, { color: isDark ? '#F8FAFC' : '#0F172A', fontSize: 28 * scale, fontFamily }]}>{medication.time}</Text>
          <Text style={[styles.detailDose, { color: isDark ? '#E2E8F0' : '#334155', fontSize: 18 * scale, fontFamily }]}>{medication.dose}</Text>
          <Text style={[styles.detailNote, { color: isDark ? '#CBD5E1' : '#475569', fontSize: 15 * scale, fontFamily }]}>{medication.notes}</Text>
        </View>

        <SectionCard title="Frequency" value={medication.frequency} accent="#BAE6FD" icon="repeat-outline" settings={settings} />
        <SectionCard title="Days" value={medication.days} accent="#DDD6FE" icon="calendar-outline" settings={settings} />
        <SectionCard title="Refill reminder" value={`${medication.refillDays} days before refill`} accent="#FDE68A" icon="time-outline" settings={settings} />
        <SectionCard title="Reminder window" value={`${settings.reminderWindow} minutes early`} accent="#A7F3D0" icon="alarm-outline" settings={settings} />
        <SectionCard title="Ringtone" value={`${settings.ringtone || medication.ringtone} • ${settings.vibration}`} accent="#FBCFE8" icon="musical-notes-outline" settings={settings} />
        <SectionCard title="Voice alerts" value={settings.voiceAlerts ? 'Enabled' : 'Disabled'} accent="#BFDBFE" icon="volume-high-outline" settings={settings} />
        <SectionCard title="Safety check" value={settings.safetyAlerts ? 'Warnings enabled' : 'Warnings paused'} accent="#FECACA" icon="shield-checkmark-outline" settings={settings} />
        <SectionCard title="Caregiver sharing" value={settings.caregiverAlerts ? 'Family alerts active' : 'Sharing off'} accent="#C7D2FE" icon="people-outline" settings={settings} />

        <View style={styles.actionRow}>
          <TouchableOpacity style={[styles.primaryButton, settings.compactMode && styles.primaryButtonCompact]} onPress={onEdit}>
            <Text style={[styles.primaryButtonText, { fontFamily }]}>Edit</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.secondaryButton, settings.compactMode && styles.secondaryButtonCompact]} onPress={onDelete}>
            <Text style={[styles.secondaryButtonText, { fontFamily }]}>Delete</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function MedicationFormScreen({ mode, initialValues, onBack, onSave, settings = {} }) {
  const [form, setForm] = useState(initialValues);
  const isDark = !!settings.darkMode;
  const fontFamily = settings.fontFamily === 'Serif' ? 'Georgia' : settings.fontFamily === 'Mono' ? 'Courier New' : undefined;
  const scale = settings.fontScale || 1;

  const updateField = (key, value) => setForm((current) => ({ ...current, [key]: value }));

  const submitForm = () => {
    if (!form.name.trim()) {
      Alert.alert('Missing name', 'Please add a medication name.');
      return;
    }

    if (!form.dose.trim()) {
      Alert.alert('Missing dosage', 'Please add a dosage value.');
      return;
    }

    onSave({ ...form, id: form.id || String(Date.now()) });
  };

  return (
    <SafeAreaView style={[styles.screenShell, isDark && styles.screenShellDark]}>
      <PageHeader title={mode === 'edit' ? 'Edit medication' : 'Add medication'} subtitle="Set dosage and reminders" onBack={onBack} settings={settings} />

      <ScrollView style={[styles.detailScroll, settings.compactMode && styles.detailScrollCompact]} showsVerticalScrollIndicator={false}>
        <View style={styles.formGroup}>
          <Text style={[styles.label, { fontFamily, fontSize: 13 * scale }]}>Medication name</Text>
          <TextInput style={[styles.input, { fontFamily }]} value={form.name} onChangeText={(value) => updateField('name', value)} placeholder="Ex: Lisinopril" />
        </View>

        <View style={styles.formGroup}>
          <Text style={[styles.label, { fontFamily, fontSize: 13 * scale }]}>Medication type</Text>
          <TextInput style={[styles.input, { fontFamily }]} value={form.type} onChangeText={(value) => updateField('type', value)} placeholder="Ex: Blood pressure" />
        </View>

        <View style={styles.formGroup}>
          <Text style={[styles.label, { fontFamily, fontSize: 13 * scale }]}>Dosage</Text>
          <TextInput style={[styles.input, { fontFamily }]} value={form.dose} onChangeText={(value) => updateField('dose', value)} placeholder="Ex: 10mg" />
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>Frequency</Text>
          <View style={styles.chipRow}>
            {frequencyOptions.map((option) => (
              <TouchableOpacity
                key={option}
                onPress={() => updateField('frequency', option)}
                style={[styles.optionChip, form.frequency === option && styles.optionChipSelected]}
              >
                <Text style={[styles.optionChipText, form.frequency === option && styles.optionChipTextSelected, { fontFamily }]}>{option}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.formGroup}>
          <Text style={[styles.label, { fontFamily, fontSize: 13 * scale }]}>Time</Text>
          <TextInput style={[styles.input, { fontFamily }]} value={form.time} onChangeText={(value) => updateField('time', value)} placeholder="08:00" />
        </View>

        <View style={styles.formGroup}>
          <Text style={[styles.label, { fontFamily, fontSize: 13 * scale }]}>Days</Text>
          <TextInput style={[styles.input, { fontFamily }]} value={form.days} onChangeText={(value) => updateField('days', value)} placeholder="Mon Tue Wed Thu Fri" />
        </View>

        <View style={styles.formGroup}>
          <Text style={[styles.label, { fontFamily, fontSize: 13 * scale }]}>Refill reminder (days)</Text>
          <TextInput style={[styles.input, { fontFamily }]} value={form.refillDays} onChangeText={(value) => updateField('refillDays', value)} placeholder="7" keyboardType="numeric" />
        </View>

        <View style={styles.formGroup}>
          <Text style={[styles.label, { fontFamily, fontSize: 13 * scale }]}>Notes</Text>
          <TextInput style={[styles.input, styles.textArea, { fontFamily }]} multiline numberOfLines={4} value={form.notes} onChangeText={(value) => updateField('notes', value)} placeholder="Take after breakfast, avoid alcohol..." />
        </View>

        <View style={styles.formGroup}>
          <Text style={[styles.label, { fontFamily, fontSize: 13 * scale }]}>Ringtone</Text>
          <View style={styles.chipRow}>
            {ringtoneOptions.map((option) => (
              <TouchableOpacity
                key={option}
                onPress={() => updateField('ringtone', option)}
                style={[styles.optionChip, form.ringtone === option && styles.optionChipSelected]}
              >
                <Text style={[styles.optionChipText, form.ringtone === option && styles.optionChipTextSelected, { fontFamily }]}>{option}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.formGroup}>
          <Text style={[styles.label, { fontFamily, fontSize: 13 * scale }]}>Color</Text>
          <View style={styles.chipRow}>
            {colorOptions.map((option) => (
              <TouchableOpacity
                key={option}
                onPress={() => updateField('color', option)}
                style={[styles.colorSwatch, { backgroundColor: option }, form.color === option && styles.colorSwatchSelected]}
              />
            ))}
          </View>
        </View>

        <TouchableOpacity style={[styles.primaryButtonLarge, settings.compactMode && styles.primaryButtonLargeCompact]} onPress={submitForm}>
          <Text style={[styles.primaryButtonText, { fontFamily }]}>{mode === 'edit' ? 'Save changes' : 'Add medication'}</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

export default function App() {
  const [screen, setScreen] = useState('home');
  const [settings, setSettings] = useState(defaultSettings);
  const [searchQuery, setSearchQuery] = useState('');
  const [medications, setMedications] = useState(initialMedications);
  const [selectedMedicationId, setSelectedMedicationId] = useState(initialMedications[0]?.id || null);
  const [transitionKey, setTransitionKey] = useState(0);
  const scaleAnim = useRef(new Animated.Value(0.98)).current;

  const medicationInsights = useMemo(() => getMedicationInsights(medications), [medications]);
  const selectedMedication = medications.find((item) => item.id === selectedMedicationId) || medications[0] || null;

  const navigate = (nextScreen, medicationId = null) => {
    playButtonClick();
    if (medicationId) {
      setSelectedMedicationId(medicationId);
    }
    Animated.sequence([
      Animated.timing(scaleAnim, { toValue: 0.98, duration: 120, useNativeDriver: true }),
      Animated.timing(scaleAnim, { toValue: 1, duration: 180, useNativeDriver: true }),
    ]).start();
    setTransitionKey((prev) => prev + 1);
    setScreen(nextScreen);
  };

  const filteredMeds = useMemo(() => {
    const term = searchQuery.trim().toLowerCase();
    if (!term) {
      return medications;
    }

    return medications.filter((med) => {
      const searchText = `${med.name} ${med.type} ${med.dose} ${med.frequency} ${med.time} ${med.days}`.toLowerCase();
      return searchText.includes(term);
    });
  }, [medications, searchQuery]);

  const goToScreen = (nextScreen, medicationId = null) => {
    navigate(nextScreen, medicationId);
  };

  const updateSetting = (key, value) => {
    playButtonClick();
    setSettings((current) => ({ ...current, [key]: value }));
  };

  const handleSaveMedication = (payload) => {
    playButtonClick();
    const medication = {
      ...payload,
      refillDays: String(payload.refillDays || '7'),
      notes: payload.notes || 'No notes added.',
      type: payload.type || 'General',
    };

    if (payload.id && medications.some((item) => item.id === payload.id)) {
      setMedications((current) => current.map((item) => (item.id === payload.id ? medication : item)));
      setSelectedMedicationId(payload.id);
    } else {
      const newMedication = { ...medication, id: String(Date.now()) };
      setMedications((current) => [newMedication, ...current]);
      setSelectedMedicationId(newMedication.id);
    }

    setSearchQuery('');
    setScreen('medication');
  };

  const handleDeleteMedication = () => {
    if (!selectedMedication) {
      return;
    }

    playButtonClick();
    setMedications((current) => current.filter((item) => item.id !== selectedMedication.id));
    setSearchQuery('');
    setScreen('home');
  };

  const renderScreen = () => {
    if (screen === 'home') {
      return (
        <HomeScreen
          settings={settings}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          filteredMeds={filteredMeds}
          insights={medicationInsights}
          onSelectMedication={(medication) => goToScreen('medication', medication.id)}
          onActionPress={(key) => {
            if (key === 'refill') goToScreen('refill');
            if (key === 'add') goToScreen('add');
            if (key === 'appointment') goToScreen('appointment');
            if (key === 'scan') goToScreen('scan');
            if (key === 'search') goToScreen('search');
            if (key === 'settings') goToScreen('settings');
            if (key === 'schedule') goToScreen('schedule');
          }}
          onSubmitSearch={() => setScreen('search')}
        />
      );
    }

    if (screen === 'search') {
      return (
        <SafeAreaView style={[styles.screenShell, settings.darkMode && styles.screenShellDark]}>
          <PageHeader
            title="Search medications"
            subtitle={filteredMeds.length ? `${filteredMeds.length} match${filteredMeds.length === 1 ? '' : 'es'}` : 'No results found'}
            onBack={() => setScreen('home')}
            settings={settings}
          />

          <View style={[styles.searchBarWrap, settings.darkMode && styles.searchBarWrapDark]}>
            <Ionicons name="search-outline" size={18} color="#64748B" />
            <TextInput
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder="Type medication name, dosage, or time"
              placeholderTextColor="#94A3B8"
              style={[styles.searchBarInput, { color: settings.darkMode ? '#F8FAFC' : '#0F172A', fontFamily: settings.fontFamily === 'Serif' ? 'Georgia' : settings.fontFamily === 'Mono' ? 'Courier New' : undefined, fontSize: 16 * (settings.fontScale || 1) }]}
              autoFocus
            />
          </View>

          <ScrollView style={styles.detailScroll} showsVerticalScrollIndicator={false}>
            {filteredMeds.length > 0 ? (
              filteredMeds.map((medication) => (
                <TouchableOpacity
                  key={medication.id}
                  onPress={() => goToScreen('medication', medication.id)}
                  style={[styles.searchResultCard, settings.darkMode && styles.searchResultCardDark, settings.compactMode && styles.searchResultCardCompact]}
                >
                  <View style={[styles.searchResultDot, { backgroundColor: medication.color }]} />
                  <View style={styles.searchResultTextWrap}>
                    <Text style={[styles.searchResultName, { color: settings.darkMode ? '#F8FAFC' : '#0F172A', fontSize: 16 * (settings.fontScale || 1), fontFamily: settings.fontFamily === 'Serif' ? 'Georgia' : settings.fontFamily === 'Mono' ? 'Courier New' : undefined }]}>{medication.name}</Text>
                    <Text style={[styles.searchResultMeta, { color: settings.darkMode ? '#CBD5E1' : '#64748B', fontSize: 13 * (settings.fontScale || 1), fontFamily: settings.fontFamily === 'Serif' ? 'Georgia' : settings.fontFamily === 'Mono' ? 'Courier New' : undefined }]}>{medication.time} • {medication.dose} • {medication.type}</Text>
                  </View>
                  <Ionicons name="chevron-forward" size={18} color="#64748B" />
                </TouchableOpacity>
              ))
            ) : (
              <View style={styles.emptyState}>
                <Text style={styles.emptyStateTitle}>No medication found</Text>
                <Text style={styles.emptyStateText}>Try a name, dose, type, or time like 8:00 or blood pressure.</Text>
                <TouchableOpacity style={styles.primaryButton} onPress={() => setScreen('add')}>
                  <Text style={styles.primaryButtonText}>Add medication</Text>
                </TouchableOpacity>
              </View>
            )}
          </ScrollView>
        </SafeAreaView>
      );
    }

    if (screen === 'medication') {
      if (!selectedMedication) {
        return (
          <SafeAreaView style={styles.screenShell}>
            <PageHeader title="No medication selected" subtitle="Add a new medication first" onBack={() => setScreen('home')} />
            <View style={styles.emptyState}>
              <Text style={styles.emptyStateTitle}>No medication found</Text>
              <Text style={styles.emptyStateText}>Add a medication so you can set up reminders and tracking.</Text>
              <TouchableOpacity style={styles.primaryButton} onPress={() => setScreen('add')}>
                <Text style={styles.primaryButtonText}>Add medication</Text>
              </TouchableOpacity>
            </View>
          </SafeAreaView>
        );
      }

      return (
        <MedicationDetailScreen
          medication={selectedMedication}
          settings={settings}
          onBack={() => setScreen('home')}
          onEdit={() => {
            setScreen('edit');
          }}
          onDelete={handleDeleteMedication}
        />
      );
    }

    if (screen === 'add') {
      return (
        <MedicationFormScreen
          mode="add"
          initialValues={getEmptyMedication()}
          onBack={() => setScreen('home')}
          onSave={handleSaveMedication}
          settings={settings}
        />
      );
    }

    if (screen === 'edit') {
      return (
        <MedicationFormScreen
          mode="edit"
          initialValues={{ ...selectedMedication }}
          onBack={() => setScreen('medication')}
          onSave={handleSaveMedication}
          settings={settings}
        />
      );
    }

    if (screen === 'settings') {
      return <SettingsScreen settings={settings} onChange={updateSetting} onBack={() => setScreen('home')} />;
    }

    if (screen === 'schedule') {
      return <ScheduleScreen settings={settings} medications={medications} onBack={() => setScreen('home')} />;
    }

    if (screen === 'refill') {
      return (
        <AppDetailScreen
          title="Refill reminder"
          subtitle="Stay on top of supplies"
          onBack={() => setScreen('home')}
          settings={settings}
          items={[
            { title: 'Metformin', value: 'Refill due in 3 days', accent: '#FDE68A', icon: 'calendar-outline' },
            { title: 'Pharmacy', value: 'Fastcare Pharmacy • 4.2 miles away', accent: '#BBF7D0', icon: 'bag-check-outline' },
            { title: 'Notes', value: 'Order before 5:00 PM for same-day pickup', accent: '#BFDBFE', icon: 'notifications-outline' },
          ]}
        />
      );
    }

    if (screen === 'appointment') {
      return (
        <AppDetailScreen
          title="Upcoming appointment"
          subtitle="Your next clinic visit"
          onBack={() => setScreen('home')}
          settings={settings}
          items={[
            { title: 'Doctor', value: 'Dr. Patel', accent: '#BFDBFE', icon: 'person-circle-outline' },
            { title: 'Visit', value: 'Thursday • 2:30 PM', accent: '#DDD6FE', icon: 'calendar-outline' },
            { title: 'Reason', value: 'Medication review and blood test follow-up', accent: '#FECACA', icon: 'document-text-outline' },
          ]}
        />
      );
    }

    if (screen === 'scan') {
      return (
        <AppDetailScreen
          title="Scan prescription"
          subtitle="Read and import medication info"
          onBack={() => setScreen('home')}
          settings={settings}
          items={[
            { title: 'Camera', value: 'Open the scanner to read the label', accent: '#C7D2FE', icon: 'camera-outline' },
            { title: 'Auto-fill', value: 'Extract dose, timing, and refill schedule', accent: '#A7F3D0', icon: 'sparkles-outline' },
            { title: 'Safety', value: 'Check for duplicate medications before saving', accent: '#FDE68A', icon: 'shield-checkmark-outline' },
          ]}
        />
      );
    }

    return null;
  };

  return (
    <Animated.View key={transitionKey} style={[styles.appShell, { transform: [{ scale: scaleAnim }] }]}>
      {renderScreen()}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  appShell: {
    flex: 1,
  },
  screenShell: {
    flex: 1,
    backgroundColor: '#F7FAFC',
  },
  screenShellDark: {
    backgroundColor: '#111827',
  },
  pageHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingTop: 18,
    paddingBottom: 12,
  },
  pageHeaderDark: {
    backgroundColor: '#111827',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  pageTitle: {
    fontSize: 26,
    fontWeight: '800',
    color: '#0F172A',
  },
  pageSubtitle: {
    marginTop: 4,
    fontSize: 14,
    color: '#64748B',
  },
  detailScroll: {
    paddingHorizontal: 18,
    paddingBottom: 24,
  },
  detailScrollCompact: {
    paddingHorizontal: 12,
  },
  calendarHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginHorizontal: 18,
    marginBottom: 14,
  },
  calendarHeaderRowDark: {
    backgroundColor: '#111827',
  },
  calendarNavButton: {
    width: 38,
    height: 38,
    borderRadius: 12,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  monthLabel: {
    fontWeight: '800',
  },
  weekdayRow: {
    flexDirection: 'row',
    marginHorizontal: 12,
    marginBottom: 8,
  },
  weekdayText: {
    flex: 1,
    textAlign: 'center',
    fontWeight: '800',
  },
  calendarGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: 12,
    marginBottom: 24,
  },
  calendarCell: {
    width: '14.2857%',
    minHeight: 66,
    borderRadius: 10,
    padding: 7,
    marginBottom: 5,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  calendarCellPlaceholder: {
    width: '14.2857%',
    minHeight: 66,
    marginBottom: 5,
  },
  calendarDayNumber: {
    fontWeight: '800',
  },
  calendarReminderRow: {
    flexDirection: 'row',
    gap: 3,
    marginTop: 12,
  },
  calendarDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  calendarMore: {
    marginTop: 3,
    fontWeight: '700',
  },
  infoCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 16,
    marginBottom: 14,
    shadowColor: '#000',
    shadowOpacity: 0.04,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  infoCardDark: {
    backgroundColor: '#1F2937',
  },
  infoCardCompact: {
    padding: 12,
    borderRadius: 14,
  },
  infoIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  infoTextWrap: {
    flex: 1,
  },
  infoTitle: {
    fontSize: 12,
    color: '#64748B',
    fontWeight: '700',
    marginBottom: 6,
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  infoValue: {
    fontSize: 16,
    color: '#0F172A',
    fontWeight: '700',
  },
  medDetailCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 22,
    borderWidth: 2,
    padding: 20,
    marginBottom: 18,
    shadowColor: '#000',
    shadowOpacity: 0.04,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  detailBadge: {
    fontSize: 11,
    color: '#475569',
    fontWeight: '800',
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 10,
  },
  detailTime: {
    fontSize: 28,
    fontWeight: '800',
    color: '#0F172A',
  },
  detailDose: {
    marginTop: 8,
    fontSize: 18,
    fontWeight: '700',
    color: '#334155',
  },
  detailNote: {
    marginTop: 14,
    fontSize: 15,
    lineHeight: 22,
    color: '#475569',
  },
  actionRow: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 8,
  },
  primaryButton: {
    flex: 1,
    backgroundColor: '#F97316',
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: 'center',
  },
  primaryButtonCompact: {
    paddingVertical: 10,
    borderRadius: 10,
  },
  secondaryButton: {
    flex: 1,
    backgroundColor: '#E2E8F0',
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: 'center',
  },
  secondaryButtonCompact: {
    paddingVertical: 10,
    borderRadius: 10,
  },
  primaryButtonText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 15,
  },
  secondaryButtonText: {
    color: '#0F172A',
    fontWeight: '700',
    fontSize: 15,
  },
  searchBarWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    paddingHorizontal: 14,
    marginHorizontal: 18,
    marginBottom: 16,
    height: 52,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  searchBarWrapDark: {
    backgroundColor: '#1F2937',
  },
  searchBarInput: {
    flex: 1,
    height: 52,
    paddingHorizontal: 10,
    color: '#0F172A',
    fontSize: 16,
  },
  searchResultCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 14,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOpacity: 0.04,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  searchResultCardDark: {
    backgroundColor: '#1F2937',
  },
  searchResultCardCompact: {
    padding: 10,
  },
  searchResultDot: {
    width: 14,
    height: 14,
    borderRadius: 7,
    marginRight: 12,
  },
  searchResultTextWrap: {
    flex: 1,
  },
  searchResultName: {
    fontSize: 16,
    fontWeight: '700',
    color: '#0F172A',
  },
  searchResultMeta: {
    marginTop: 4,
    fontSize: 13,
    color: '#64748B',
  },
  emptyState: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 22,
    alignItems: 'center',
    marginTop: 20,
  },
  emptyStateTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: '#0F172A',
    marginBottom: 8,
  },
  emptyStateText: {
    fontSize: 15,
    color: '#64748B',
    textAlign: 'center',
    marginBottom: 18,
  },
  settingsBlock: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOpacity: 0.04,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  settingsHeading: {
    fontSize: 15,
    fontWeight: '800',
    color: '#0F172A',
    marginBottom: 14,
  },
  settingsDescription: {
    fontSize: 13,
    lineHeight: 19,
    marginTop: -6,
    marginBottom: 14,
  },
  settingsLabel: {
    fontSize: 12,
    fontWeight: '800',
    marginTop: 8,
    marginBottom: 2,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  settingsBlockDark: {
    backgroundColor: '#1F2937',
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
  },
  settingLabel: {
    fontSize: 15,
    color: '#1E293B',
    fontWeight: '600',
  },
  toggle: {
    width: 52,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#CBD5E1',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  toggleOn: {
    backgroundColor: '#F97316',
  },
  toggleKnob: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: '#FFFFFF',
    marginLeft: 0,
  },
  toggleKnobOn: {
    marginLeft: 22,
  },
  chipRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 4,
  },
  optionChip: {
    backgroundColor: '#F1F5F9',
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginRight: 8,
    marginBottom: 8,
  },
  optionChipSelected: {
    backgroundColor: '#0F172A',
  },
  optionChipText: {
    color: '#334155',
    fontWeight: '700',
    fontSize: 12,
  },
  optionChipTextSelected: {
    color: '#FFFFFF',
  },
  formGroup: {
    marginBottom: 18,
  },
  label: {
    fontSize: 13,
    fontWeight: '800',
    color: '#475569',
    marginBottom: 8,
    textTransform: 'uppercase',
    letterSpacing: 0.75,
  },
  input: {
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 16,
    color: '#0F172A',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  textArea: {
    minHeight: 90,
    textAlignVertical: 'top',
  },
  primaryButtonLarge: {
    backgroundColor: '#F97316',
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 12,
    marginBottom: 28,
  },
  primaryButtonLargeCompact: {
    paddingVertical: 12,
  },
  colorSwatch: {
    width: 28,
    height: 28,
    borderRadius: 14,
    marginRight: 10,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  colorSwatchSelected: {
    borderColor: '#0F172A',
  },
});
