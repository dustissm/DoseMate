import { useState } from 'react';
import { Pressable, SafeAreaView, StyleSheet, Text, View } from 'react-native';

const colors = ['#F97316', '#0EA5E9', '#10B981', '#EAB308'];

export default function RandomScreen({ route }) {
  const { title, subtitle, items } = route.params;
  const [selectedItem, setSelectedItem] = useState(items[0]);

  const shuffle = () => {
    const nextItem = items[Math.floor(Math.random() * items.length)];
    setSelectedItem(nextItem);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.intro}>
        <Text style={styles.eyebrow}>JUST FOR FUN</Text>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.subtitle}>{subtitle}</Text>
      </View>

      <View style={styles.list}>
        {items.map((item, index) => (
          <Pressable
            key={item}
            onPress={() => setSelectedItem(item)}
            style={({ pressed }) => [
              styles.item,
              selectedItem === item && styles.selectedItem,
              pressed && styles.pressed,
            ]}
          >
            <View style={[styles.dot, { backgroundColor: colors[index] }]} />
            <Text style={styles.itemText}>{item}</Text>
            <Text style={styles.arrow}>›</Text>
          </Pressable>
        ))}
      </View>

      <Pressable onPress={shuffle} style={({ pressed }) => [styles.shuffle, pressed && styles.shufflePressed]}>
        <Text style={styles.shuffleText}>Surprise me</Text>
        <Text style={styles.shuffleIcon}>✦</Text>
      </Pressable>

      <Text style={styles.selected}>Selected: {selectedItem}</Text>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
    padding: 24,
  },
  intro: {
    marginBottom: 28,
  },
  eyebrow: {
    color: '#F97316',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.5,
    marginBottom: 8,
  },
  title: {
    color: '#0F172A',
    fontSize: 32,
    fontWeight: '800',
    marginBottom: 8,
  },
  subtitle: {
    color: '#64748B',
    fontSize: 16,
  },
  list: {
    gap: 12,
  },
  item: {
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderColor: '#E2E8F0',
    borderRadius: 14,
    borderWidth: 1,
    flexDirection: 'row',
    minHeight: 64,
    paddingHorizontal: 18,
  },
  selectedItem: {
    borderColor: '#F97316',
    borderWidth: 2,
  },
  pressed: {
    opacity: 0.7,
  },
  dot: {
    borderRadius: 8,
    height: 16,
    marginRight: 14,
    width: 16,
  },
  itemText: {
    color: '#1E293B',
    flex: 1,
    fontSize: 16,
    fontWeight: '600',
  },
  arrow: {
    color: '#94A3B8',
    fontSize: 26,
    lineHeight: 26,
  },
  shuffle: {
    alignItems: 'center',
    backgroundColor: '#F97316',
    borderRadius: 14,
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 28,
    minHeight: 54,
  },
  shufflePressed: {
    backgroundColor: '#EA580C',
  },
  shuffleText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  shuffleIcon: {
    color: '#FFFFFF',
    fontSize: 21,
    marginLeft: 8,
  },
  selected: {
    color: '#94A3B8',
    fontSize: 13,
    marginTop: 18,
    textAlign: 'center',
  },
});
