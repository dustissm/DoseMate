import { Ionicons } from '@expo/vector-icons';
import { useEffect, useMemo, useState } from 'react';
import {
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { getTranslation } from './localization';

const actionCards = [
  { key: 'refill', title: 'Refill', subtitle: 'Reminder', icon: 'notifications-outline', color: '#FDE68A' },
  { key: 'add', title: 'Add', subtitle: 'Medication', icon: 'add-circle-outline', color: '#BBF7D0' },
  { key: 'appointment', title: 'Upcoming', subtitle: 'Appointment', icon: 'calendar-outline', color: '#BFDBFE' },
  { key: 'scan', title: 'Scan', subtitle: 'Prescription', icon: 'scan-outline', color: '#DDD6FE' },
];

const bottomNav = [
  { key: 'home', label: 'Home', icon: 'home-outline' },
  { key: 'search', label: 'Search', icon: 'search-outline' },
  { key: 'schedule', label: 'Schedule', icon: 'calendar-outline' },
  { key: 'settings', label: 'Settings', icon: 'settings-outline' },
];

export default function HomeScreen({
  settings,
  searchQuery,
  setSearchQuery,
  filteredMeds,
  insights,
  coachTips = [],
  onSelectMedication,
  onActionPress,
  onSubmitSearch,
}) {
  const topMeds = useMemo(() => filteredMeds.slice(0, 3), [filteredMeds]);
  const [currentTime, setCurrentTime] = useState(() => getPacificTime(settings.showSeconds));

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(getPacificTime(settings.showSeconds)), 1000);
    return () => clearInterval(timer);
  }, [settings.showSeconds]);

  const isDark = settings.darkMode;
  const scale = settings.fontScale || 1;
  const accentColor = settings.accentColor || '#F97316';
  const fontFamily = settings.fontFamily === 'Serif' ? 'Georgia' : settings.fontFamily === 'Mono' ? 'Courier New' : undefined;
  const contrastText = settings.highContrast ? (isDark ? '#FFFFFF' : '#020617') : (isDark ? '#F8FAFC' : '#0F172A');
  const mutedText = settings.highContrast ? (isDark ? '#F8FAFC' : '#334155') : '#64748B';
  const surfaceColor = settings.highContrast ? (isDark ? '#000000' : '#FFFFFF') : (isDark ? '#1F2937' : '#FFFFFF');
  const t = getTranslation(settings.language);
  const navLabels = { home: t.home, search: t.search, schedule: t.schedule, settings: t.settings };

  return (
    <SafeAreaView style={[styles.container, isDark && styles.containerDark]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.headerRow}>
          <Text style={[styles.clock, { color: contrastText, fontSize: 32 * scale, fontFamily }]}>{currentTime}</Text>
          <Ionicons name="notifications-outline" size={24} color={settings.voiceAlerts ? accentColor : mutedText} />
        </View>

        <View style={[styles.searchWrap, isDark && styles.surfaceDark]}>
          <Ionicons name="search-outline" size={18} color="#64748B" />
          <TextInput
            value={searchQuery}
            onChangeText={setSearchQuery}
            onSubmitEditing={onSubmitSearch}
            placeholder={t.searchMedication}
            placeholderTextColor="#94A3B8"
            style={[styles.searchInput, { color: contrastText, fontSize: 16 * scale, fontFamily }]}
          />
        </View>

        <View style={styles.heroCard}>
          <View>
            <Text style={[styles.heroLabel, { fontFamily }]}>{t.today}</Text>
            <Text style={[styles.heroTitle, { fontSize: 22 * scale, fontFamily }]}>{settings.dailySummary ? t.medicationSummary : t.dailySummaryPaused}</Text>
          </View>
          <Text style={[styles.heroBadge, { backgroundColor: accentColor, fontFamily }]}>{settings.voiceAlerts ? t.voiceOn : t.silent} · {filteredMeds.length}</Text>
        </View>

        <View style={[styles.insightPanel, { backgroundColor: surfaceColor, borderWidth: settings.highContrast ? 2 : 0, borderColor: contrastText }]}> 
          <View style={styles.insightHeaderRow}>
            <Text style={[styles.insightTitle, { color: contrastText, fontFamily }]}>Smart health brief</Text>
            <Text style={[styles.insightScore, { color: accentColor, fontFamily }]}>{insights?.adherence ?? 92}%</Text>
          </View>
          <View style={styles.metricRow}>
            <View style={[styles.metricBox, settings.highContrast && styles.metricBoxHighContrast, settings.highContrast && isDark && styles.metricBoxHighContrastDark, settings.compactMode && styles.metricBoxCompact]}>
              <Text style={[styles.metricValue, { color: contrastText, fontFamily }]}>{insights?.refillSoon ?? 0}</Text>
              <Text style={[styles.metricLabel, { color: mutedText, fontFamily }]}>Refill soon</Text>
            </View>
            <View style={[styles.metricBox, settings.highContrast && styles.metricBoxHighContrast, settings.highContrast && isDark && styles.metricBoxHighContrastDark, settings.compactMode && styles.metricBoxCompact]}>
              <Text style={[styles.metricValue, { color: contrastText, fontFamily }]}>{insights?.total ?? 0}</Text>
              <Text style={[styles.metricLabel, { color: mutedText, fontFamily }]}>Active meds</Text>
            </View>
            <View style={[styles.metricBox, settings.highContrast && styles.metricBoxHighContrast, settings.highContrast && isDark && styles.metricBoxHighContrastDark, settings.compactMode && styles.metricBoxCompact]}>
              <Text style={[styles.metricValue, { color: contrastText, fontFamily }]}>{insights?.alertCount ?? 0}</Text>
              <Text style={[styles.metricLabel, { color: mutedText, fontFamily }]}>Alerts</Text>
            </View>
          </View>
          {coachTips.length > 0 && (
            <View style={styles.coachTipsWrap}>
              {coachTips.slice(0, 2).map((tip) => (
                <Text key={tip} style={[styles.coachTip, { color: mutedText, fontFamily }]}>{tip}</Text>
              ))}
            </View>
          )}
        </View>

        <View style={styles.cardGrid}>
          {actionCards.map((card) => (
            <TouchableOpacity
              key={card.key}
              activeOpacity={0.85}
              style={[styles.actionCard, { backgroundColor: settings.highContrast ? surfaceColor : card.color, minHeight: settings.compactMode ? 76 : 120, padding: settings.compactMode ? 9 : 16, borderWidth: settings.highContrast ? 2 : 0, borderColor: contrastText }]}
              onPress={() => onActionPress(card.key)}
            >
              <Ionicons name={card.icon} size={26} color="#0F172A" />
              <Text style={[styles.cardTitle, { color: contrastText, fontSize: 20 * scale, fontFamily }]}>{card.title}</Text>
              <Text style={[styles.cardSubtitle, { color: contrastText, fontFamily }]}>{card.key === 'refill' && !settings.autoRefill ? t.silent : card.subtitle}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.medsHeaderRow}>
          <Text style={[styles.sectionTitle, { color: contrastText, fontSize: 20 * scale, fontFamily }]}>{t.myMedications}</Text>
          <TouchableOpacity onPress={onSubmitSearch}>
            <Text style={[styles.viewAllText, { color: accentColor, fontFamily }]}>{t.viewAll}</Text>
          </TouchableOpacity>
        </View>

        {topMeds.map((medication) => (
          <TouchableOpacity
            key={medication.id}
            activeOpacity={0.8}
            style={[styles.medRow, { backgroundColor: surfaceColor, padding: settings.compactMode ? 8 : 14, borderWidth: settings.highContrast ? 2 : 0, borderColor: contrastText }]}
            onPress={() => onSelectMedication(medication)}
          >
            <View style={[styles.medColorDot, { backgroundColor: medication.color }]} />
            <View style={styles.medTextWrap}>
              <Text style={[styles.medName, { color: contrastText, fontSize: 16 * scale, fontFamily }]}>{medication.name}</Text>
              <Text style={[styles.medMeta, { color: mutedText, fontSize: 13 * scale, fontFamily }]}>{medication.time} • {medication.dose}</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={mutedText} />
          </TouchableOpacity>
        ))}
      </ScrollView>

      <View style={[styles.bottomNav, { backgroundColor: surfaceColor, paddingBottom: settings.compactMode ? 10 : 18 }]}>
        {bottomNav.map((item) => (
          <TouchableOpacity
            key={item.key}
            style={styles.navItem}
            onPress={() => onActionPress(item.key)}
          >
            <Ionicons
              name={item.icon}
              size={22}
              color={item.key === 'home' ? accentColor : mutedText}
            />
            <Text style={[styles.navLabel, { color: item.key === 'home' ? accentColor : mutedText, fontSize: 11 * scale, fontFamily }]}>{navLabels[item.key]}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </SafeAreaView>
  );
}

function getPacificTime(showSeconds = false) {
  return new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/Los_Angeles',
    hour: 'numeric',
    minute: '2-digit',
    ...(showSeconds ? { second: '2-digit' } : {}),
  }).format(new Date());
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F4F7FB',
  },
  containerDark: {
    backgroundColor: '#111827',
  },
  surfaceDark: {
    backgroundColor: '#1F2937',
  },
  textDark: {
    color: '#F8FAFC',
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 16,
    marginBottom: 14,
  },
  clock: {
    fontSize: 32,
    fontWeight: '800',
    color: '#0F172A',
  },
  searchWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    marginHorizontal: 20,
    height: 52,
    paddingHorizontal: 14,
    shadowColor: '#000',
    shadowOpacity: 0.04,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  searchInput: {
    flex: 1,
    marginLeft: 10,
    fontSize: 16,
    color: '#0F172A',
  },
  heroCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#0F172A',
    borderRadius: 22,
    marginHorizontal: 20,
    marginTop: 18,
    marginBottom: 20,
    padding: 20,
  },
  heroLabel: {
    color: '#C7D2FE',
    fontSize: 12,
    letterSpacing: 1,
    textTransform: 'uppercase',
    fontWeight: '700',
  },
  heroTitle: {
    marginTop: 8,
    color: '#FFFFFF',
    fontSize: 22,
    fontWeight: '800',
  },
  heroBadge: {
    fontSize: 12,
    fontWeight: '700',
    backgroundColor: '#F97316',
    color: '#FFFFFF',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
  },
  insightPanel: {
    marginHorizontal: 20,
    marginBottom: 16,
    borderRadius: 20,
    padding: 16,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 2 },
    elevation: 3,
  },
  insightHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  insightTitle: {
    fontSize: 15,
    fontWeight: '800',
  },
  insightScore: {
    fontSize: 18,
    fontWeight: '800',
  },
  metricRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 10,
  },
  metricBox: {
    flex: 1,
    backgroundColor: '#F8FAFC',
    borderRadius: 14,
    paddingVertical: 12,
    paddingHorizontal: 10,
    alignItems: 'center',
  },
  metricBoxHighContrast: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#020617',
  },
  metricBoxHighContrastDark: {
    backgroundColor: '#000000',
    borderColor: '#FFFFFF',
  },
  metricBoxCompact: {
    paddingVertical: 7,
    paddingHorizontal: 6,
  },
  metricValue: {
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 4,
  },
  metricLabel: {
    fontSize: 11,
    textAlign: 'center',
  },
  coachTipsWrap: {
    marginTop: 12,
    gap: 8,
  },
  coachTip: {
    fontSize: 12,
    lineHeight: 18,
  },
  cardGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    marginBottom: 22,
  },
  actionCard: {
    width: '48%',
    minHeight: 120,
    borderRadius: 20,
    padding: 16,
    justifyContent: 'center',
    marginBottom: 14,
    shadowColor: '#000',
    shadowOpacity: 0.04,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  cardTitle: {
    marginTop: 12,
    fontSize: 20,
    fontWeight: '800',
    color: '#0F172A',
  },
  cardSubtitle: {
    marginTop: 4,
    fontSize: 13,
    color: '#0F172A',
    opacity: 0.75,
  },
  medsHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 10,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: '#0F172A',
  },
  viewAllText: {
    color: '#F97316',
    fontWeight: '700',
    fontSize: 14,
  },
  medRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    marginHorizontal: 20,
    marginBottom: 12,
    padding: 14,
    shadowColor: '#000',
    shadowOpacity: 0.04,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  medColorDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 12,
  },
  medTextWrap: {
    flex: 1,
  },
  medName: {
    fontSize: 16,
    fontWeight: '700',
    color: '#0F172A',
  },
  medMeta: {
    marginTop: 4,
    fontSize: 13,
    color: '#64748B',
  },
  bottomNav: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingTop: 12,
    paddingBottom: 18,
    borderTopWidth: 1,
    borderTopColor: '#E2E8F0',
  },
  navItem: {
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 60,
  },
  navLabel: {
    marginTop: 6,
    fontSize: 11,
    fontWeight: '700',
    color: '#64748B',
  },
  navLabelActive: {
    color: '#F97316',
  },
});

