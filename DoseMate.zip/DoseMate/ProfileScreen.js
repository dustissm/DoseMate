import { StyleSheet, View, Text, TouchableOpacity, ScrollView, Vibration } from 'react-native';

export default function ProfileScreen() {
  const playSound = (buttonLabel, frequency) => {
    // Unique vibration patterns for each button
    const patterns = {
      'Beep': [50, 50],
      'Boop': [100, 100],
      'Pop': [150],
      'Buzz': [30, 30, 30, 30, 30],
      'Ding': [100, 50, 100],
      'Chirp': [50, 30, 50],
      'Whoosh': [200, 100],
      'Ping': [75],
    };

    const pattern = patterns[buttonLabel] || [100];
    Vibration.vibrate(pattern);
    console.log(`🎵 ${buttonLabel} played!`);
  };

  const buttons = [
    { label: 'Beep', color: '#667BC6' },
    { label: 'Boop', color: '#DA7297' },
    { label: 'Pop', color: '#FADA7A' },
    { label: 'Buzz', color: '#82CD47' },
    { label: 'Ding', color: '#62D9FF' },
    { label: 'Chirp', color: '#FF6B9D' },
    { label: 'Whoosh', color: '#C44569' },
    { label: 'Ping', color: '#00B4A6' },
  ];

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Profile Screen - Sound Buttons</Text>
      <View style={styles.buttonsGrid}>
        {buttons.map((btn, index) => (
          <TouchableOpacity
            key={index}
            style={[styles.button, { backgroundColor: btn.color }]}
            onPress={() => playSound(btn.label, 300 + index * 50)}
          >
            <Text style={styles.buttonText}>{btn.label}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  buttonsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  button: {
    width: '48%',
    paddingVertical: 25,
    marginBottom: 15,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  buttonText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#fff',
  },
});

